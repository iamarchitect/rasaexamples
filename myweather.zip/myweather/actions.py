from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_core_sdk import Action
from rasa_core_sdk.events import SlotSet

class ActionWeather(Action):
	def name(self):
		return 'action_weather'
		
	#def run(self, dispatcher, tracker, domain):
		#from apixu.client import ApixuClient
		
		#print("CALLED here+++++++++++++++++++++++++++++++++++++++++++++++++")
		#api_key = '63149cc859a94b029c563934181111'
		#client = ApixuClient(api_key)
		
		#loc = tracker.get_slot('location')
		#current = client.getCurrentWeather(q=loc)
		
		#country = 'India'
		#city = 'Bangalore'
		#condition = 'Summer'
		#temperature_c = '20'
		#humidity = current['current']['humidity']
		#wind_mph = current['current']['wind_mph']

		#response = """It is currently {} in {} at the moment. The temperature is {} degrees.""".format(condition, city, temperature_c)
						
		#dispatcher.utter_message(response)
		#return [SlotSet('location',loc)]
		
	def run(self, dispatcher, tracker, domain):
		from apixu.client import ApixuClient
		api_key = '63149cc859a94b029c563934181111'
		client = ApixuClient(api_key)
		
		loc = tracker.get_slot('location')
		current = client.getCurrentWeather(q=loc)
		
		country = current['location']['country']
		city = current['location']['name']
		condition = current['current']['condition']['text']
		temperature_c = current['current']['temp_c']
		humidity = current['current']['humidity']
		wind_mph = current['current']['wind_mph']

		response = """It is currently {} in {} at the moment. The temperature is {} degrees, the humidity is {}% and the wind speed is {} mph.""".format(condition, city, temperature_c, humidity, wind_mph)
						
		dispatcher.utter_message(response)
		return [SlotSet('location',loc)]

